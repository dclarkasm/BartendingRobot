EN   Your download from the 24.10.2013 on PARTcommunity/PARTserver:

       Dear user,
       
       attached please find the following file of our 3D CAD download portal PARTcommunity/PARTserver powered by CADENAS:

       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H 10A + 340L0 - 10A0(0-0).iam
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H(A-1)-Slider.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-340-Protected Cover.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-A-Slider Spacer.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45HA-340L-1A0-Body.ipt
	
       Information for use:

       The attached file was compressed ("ZIP"), in order to ensure a faster download.
       In order to unpack the file you need a special decompressing software. 

       Should you not have any decompressing software installed, you can download it under the following links:
       PKZip� (http://www.pkware.com) or WinZip� (http://www.winzip.com)

       Please also check terms of use at http://www.cadenas.de/terms-of-use-3d-cad-models

       Best regards

       Your CADENAS GmbH
       support@cadenas.de

       >> Free APP for 3D CAD models <<
       
       Mobile access to 3D CAD models with your Smartphone or Tablet PC. 
       Download now at http://www.cadenas.de/en/app-store


       >> PARTcommunity - The network and information platform for engineers <<
       
       � Examples of use and ideas for components 
       � Information and experience exchange with other engineers

       Join the discussion now at http://www.partcommunity.com


       >> PARTsolutions - Find & manage standard, purchased, and own parts <<

       Reduce total product costs up to 70% in the development phase?

       In many companies PARTsolutions is one of the leading software systems helping
       engineers and purchasers to manage and find company-, supplier- and standard parts:

       � PURCHINEERING: Optimize cooperation of Purchasing and Engineering
       � Semiautomatic classification and intelligent search methods
       � Open for all systems such as PLM and ERP

       More information at http://www.cadenas.de/strategic-partsmanagement


D    Ihr Download vom 24.10.2013 auf PARTcommunity/PARTserver:

       Sehr geehrter Nutzer,
       
       im Anhang finden Sie folgende Datei unseres 3D CAD Downloadportals PARTcommunity/PARTserver powered by CADENAS:

       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H 10A + 340L0 - 10A0(0-0).iam
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H(A-1)-Slider.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-340-Protected Cover.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-A-Slider Spacer.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45HA-340L-1A0-Body.ipt
	
       Hinweise zur Nutzung:

       Die beigef�gte Datei wurde komprimiert ("ZIP"), um einen schnelleren Download zu erm�glichen.
       Zum Entpacken der Datei ben�tigen Sie eine spezielle Dekomprimierungssoftware. 

       Sollten Sie noch keine Software zum Entpacken installiert haben, k�nnen Sie diese unter 
       folgenden Links downloaden: PKZip� (http://www.pkware.com) oder WinZip� (http://www.winzip.com)

       Bitte beachten Sie auch die Download Vereinbarung unter http://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
       
       Mit freundlichen Gr��en

       Ihre CADENAS GmbH
       support@cadenas.de
       

       >> Kostenlose APP f�r 3D CAD Modelle <<
       
       Mobiler Zugriff auf 3D CAD Modelle mit Ihrem Smartphone oder Tablet PC. 
       
       Jetzt downloaden unter http://www.cadenas.de/de/app-store


       >> PARTcommunity - Die Netzwerk- und Informationsplattform f�r Ingenieure <<
       
       � Anwendungsbeispiele und -ideen f�r Komponenten 
       � Erfahrungsaustausch mit anderen Ingenieuren

       Jetzt mitdiskutieren unter http://www.partcommunity.com


       >> PARTsolutions - Norm-, Kauf- und Eigenteilen finden und verwalten <<

       Produktgesamtkosten bereits in der Entwicklungsphase um bis zu 70 % senken?

       PARTsolutions dient Ingenieuren und Eink�ufern in vielen Unternehmen als leitendes Softwaresystem zum
       Verwalten und Finden von Eigen-, Kauf- und Normteilen:

       � PURCHINEERING: Zusammenarbeit von Einkauf und Engineering optimieren
       � Semiautomatische Klassifikation und intelligente Suchmethoden
       � Offen f�r alle Systeme wie PLM und ERP


F    Votre commande du 24.10.2013 sur PARTcommunity/PARTserver :

       Tr�s cher utilisateur,
       
       Veuillez trouver en pi�ce attach�e les fichiers CAO 3D suivants de notre portail de t�lechargement 
       PARTcommunity/PARTserver powered by CADENAS :

       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H 10A + 340L0 - 10A0(0-0).iam
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H(A-1)-Slider.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-340-Protected Cover.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-A-Slider Spacer.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45HA-340L-1A0-Body.ipt
	
       Indications sur l'utilisation :

       Le fichier ci-joint a �t� comprim� ("ZIP") pour permettre un t�l�chargement plus rapide.
       Pour extraire le fichier, un programme d'extraction est n�cessaire. 

       Si vous ne disposez pas d'un tel programme, vous pouvez en t�l�charger un sous : 
       PKZip� (http://www.pkware.com) ou WinZip� (http://www.winzip.com)

       Veuillez �galement v�rifier les conditions d'utilisation sur http://www.cadenas.de/fr/terms-of-use-3d-cad-models
       
       Sinc�res salutations

       CADENAS GmbH
       support@cadenas.de


       >> APP gratuite pour le mod�les CAO <<
       
       Acc�s mobile sur le mod�les CAO 3D avec votre Smartphone ou Tablet PC. 
       
       T�l�chargez maintenant sous http://www.cadenas.de/en/app-store


       >> PARTcommunity - La plateforme sociale et d'information pour les ing�nieurs <<
       
       � Exemples et id�es d'application des composants 
       � Echange d'exp�rience avec d'autres ing�nieurs

       Discutez maintenant sous http://www.partcommunity.com


       >> PARTsolutions - Trouver et g�rer les pi�ces normalis�es, pi�ces du commerce et standard <<

       R�duire de 70% vos frais de production d�j� dans la phase de d�veloppement ?

       PARTsolutions est consid�r� comme syst�me leader dans de nombreuses entreprises pour les services 
       techniques et achats dans le cadre d�une gestion optimis�e des pi�ces du commerces et normes.

       � PURCHINEERING: Optimiser la coop�ration des achats et l'ing�nierie
       � Classification semi-automatique et m�thodes de recherche intelligentes
       � Ouvert pour tous les syst�mes PLM et ERP

       De plus amples informations sous http://www.cadenas.fr


IT   Download di 24.10.2013 da PARTcommunity/PARTserver:

       Gentile Utente,
       
       in allegato i seguenti file del nostro portale download parti CAD 3D PARTcommunity/PARTserver 
       powered by CADENAS:

       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H 10A + 340L0 - 10A0(0-0).iam
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H(A-1)-Slider.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-340-Protected Cover.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-A-Slider Spacer.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45HA-340L-1A0-Body.ipt
	
       Indicazioni per l'utilizzo:

       L'allegato � stato compresso ("ZIP") per poterlo scaricare pi� velocemente.
       Per aprire il file � necessario un software speciale per decomprimerlo. 

       Se non si possiede un software per la decompressione gi� installato, � possibile scaricarlo dai 
       seguenti link: PKZip� (http://www.pkware.com) oppure WinZip� (http://www.winzip.com)

       Please also check terms of use at http://www.cadenas.de/terms-of-use-3d-cad-models
       
       Con i migliori saluti

       CADENAS GmbH
       support@cadenas.de


       >> APP gratuita per modelli CAD 3D <<
       
       Accesso mobile ai modelli CAD 3D dal vostro Smartphone o Tablet PC. 
       
       Scaricala ora da http://www.cadenas.de/en/app-store


       >> PARTcommunity - La piattaforma di rete e di informazione per gli ingegneri <<
       
       � Esempi di utilizzo e idee per componenti 
       � Scambio di esperienze con altri ingegneri

       Partecipa alla discussione su http://www.partcommunity.com


       >> PARTsolutions - Trovare e utilizzare parti a norma, commerciali e interne <<

       Costi totali del prodotto gi� nella fase di sviluppo e loro possibile riduzione fino al 70 %!

       La Gestione Strategica delle Parti PARTsolutions, in molte aziende viene usato come sistema leader 
       per il supporto a Ingegnieri, Progettisti, l�Engineering e Responsabili Commerciali nel utilizzo della 
       ricerca di parti a norma, commerciali e interne.

       � PURCHINEERING: Ottimizzare la collaborazione tra ufficio acquisti e progettazione 
       � Classificazione semi-automatica e modalit� di ricerca intelligente 
       � Aperto a tutti i sistemi, come PLM ed ERP

       Maggiori informazioni alla pagina http://www.cadenas.it/gestione-delle-parti


ES   Download de 24.10.2013 desde PARTcommunity/PARTserver:

       Estimado Usuario,
       
       adjunto los siguientes archivos de nuestro portal de download de modelos CAD 3D PARTcommunity/PARTserver 
       powered by CADENAS:

       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H 10A + 340L0 - 10A0(0-0).iam
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H(A-1)-Slider.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-340-Protected Cover.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45H-A-Slider Spacer.ipt
       AIS2011, KR45H 10A + 340L0 - 10A0(0-0), KR45HA-340L-1A0-Body.ipt
	
       Indicaciones para el uso:

       El anexo ha sido comprimido ("ZIP") para poder descargarlo m�s r�pidamente.
       Para abrir el archivo se necesita un programa inform�tico para descomprimir los archivos. 

       Si no se dispone de un software para la extracci�n de archivos, es posible descargarlo  desde los
       siguientes enlaces: PKZip� (http://www.pkware.com) o WinZip� (http://www.winzip.com)

       Please also check terms of use at http://www.cadenas.de/terms-of-use-3d-cad-models
       
       Atentamente

       CADENAS GmbH
       support@cadenas.de


       >> Aplicaci�n gratuita para modelos CAD 3D <<
       
       Acceso m�vil a los modelos CAD 3D desde vuestro Smartphone o Tablet PC. 
       
       Descargue ahora desde http://www.cadenas.de/en/app-store


       >> PARTcommunity - lLa plataforma de red  y informaci�n para los ingenieros <<
       
       � Ejemplos de uso e ideas para componentes
       � Intercambio de experiencias con otros ingenieros

       Participe en el debate en el sitio http://www.partcommunity.com
